What I changed in test files:

sfs_test0.c - Nothing
sfs_test1.c - MAX_FNAME_LENGTH 15
sfs_test2.c - MAX_FNAME_LENGTH 15

To execute, run:
make clean
make
 ./PhilippeBergeron